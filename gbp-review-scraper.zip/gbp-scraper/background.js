// Background service worker for GBP Review Scraper

let waitingForReload = {};

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ tabId: tab.id });

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } catch (error) {
    // Content script may already be injected — safe to ignore
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'page_will_reload') {
    waitingForReload[sender.tab.id] = true;
  }
  return false;
});

// Re-inject content script after page reload (e.g. after clicking Reviews on search-kg)
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId === 0 && waitingForReload[details.tabId]) {
    delete waitingForReload[details.tabId];

    // Let the page settle before re-injecting
    await new Promise(resolve => setTimeout(resolve, 1200));

    try {
      await chrome.scripting.executeScript({
        target: { tabId: details.tabId },
        files: ['content.js']
      });
    } catch (error) {
      console.error('GBP Scraper: Failed to re-inject content script after reload:', error);
    }
  }
});
