// Side panel JS for GBP Review Scraper

let reviewsData = null;

// ─── DOM refs ────────────────────────────────────────────────────────────────
const instructions       = document.getElementById('instructions');
const contentScroll      = document.getElementById('content-scroll');
const progressContainer  = document.getElementById('progress-container');
const progressBar        = document.getElementById('progress-bar');
const progressText       = document.getElementById('progress-text');
const errorContainer     = document.getElementById('error-container');
const errorMessage       = document.getElementById('error-message');
const errorDetails       = document.getElementById('error-details');
const resultsContainer   = document.getElementById('results-container');
const resultsSummary     = document.getElementById('results-summary');
const resultsBody        = document.getElementById('results-body');
const downloadContainer  = document.getElementById('download-container');
const downloadLabel      = document.getElementById('download-label');

// ─── Step indicator logic ────────────────────────────────────────────────────
// percent thresholds → which step is "active"
function updateSteps(percent) {
  // steps: 1=0-15, 2=15-25, 3=25-62, 4=62-82, 5=82-100
  const thresholds = [0, 15, 25, 62, 82];
  for (let i = 1; i <= 5; i++) {
    const el = document.getElementById(`step-${i}`);
    if (!el) continue;
    const low = thresholds[i - 1];
    const high = thresholds[i] ?? 100;
    if (percent > high) {
      el.className = 'step done';
      el.querySelector('.step-dot').textContent = '✓';
    } else if (percent >= low) {
      el.className = 'step active';
      el.querySelector('.step-dot').textContent = i;
    } else {
      el.className = 'step';
      el.querySelector('.step-dot').textContent = i;
    }
  }
}

// ─── Message handlers ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'progress') handleProgress(message.percent, message.text);
  else if (message.type === 'reviews') handleReviews(message.data);
  else if (message.type === 'error')   handleError(message.message, message.details);
});

function handleProgress(percent, text) {
  instructions.style.display      = 'none';
  contentScroll.style.display = 'block';
  progressContainer.style.display = 'block';
  errorContainer.style.display    = 'none';
  resultsContainer.style.display  = 'none';
  downloadContainer.style.display = 'none';

  progressBar.style.width = percent + '%';
  progressText.textContent = text;
  updateSteps(percent);
}

function handleReviews(reviews) {
  reviewsData = reviews;

  contentScroll.style.display     = 'none';
  resultsContainer.style.display  = 'flex';
  downloadContainer.style.display = 'block';

  resultsSummary.textContent = `${reviews.length} review${reviews.length !== 1 ? 's' : ''} extracted`;
  downloadLabel.textContent  = `Download CSV  (${reviews.length} review${reviews.length !== 1 ? 's' : ''})`;

  resultsBody.innerHTML = '';

  reviews.forEach(review => {
    const row = document.createElement('tr');

    row.appendChild(makeCell(review.name,     'cell-name'));
    row.appendChild(makeStarCell(review.rating));
    row.appendChild(makeCell(review.date,     'cell-date'));
    row.appendChild(makeCell(review.content,  'cell-content'));
    row.appendChild(makeCell(review.response, 'cell-response'));

    resultsBody.appendChild(row);
  });
}

function handleError(message, details) {
  instructions.style.display      = 'none';
  contentScroll.style.display     = 'block';
  progressContainer.style.display = 'none';
  resultsContainer.style.display  = 'none';
  downloadContainer.style.display = 'none';
  errorContainer.style.display    = 'block';

  errorMessage.textContent = message;

  if (details) {
    errorDetails.textContent = details;
    document.getElementById('error-toggle').style.display = 'inline';
  } else {
    document.getElementById('error-toggle').style.display = 'none';
    errorDetails.style.display = 'none';
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function makeCell(text, className) {
  const td = document.createElement('td');
  td.className = className || '';
  td.textContent = text || '';
  return td;
}

function makeStarCell(ratingText) {
  const td = document.createElement('td');
  td.className = 'cell-rating';

  // Try to extract numeric star count from text like "5 stars" or "Rated 4 out of 5"
  const match = ratingText && ratingText.match(/(\d)/);
  if (match) {
    const n = parseInt(match[1], 10);
    const stars = document.createElement('span');
    stars.className = 'stars';
    stars.title = ratingText;
    stars.textContent = '★'.repeat(Math.min(n, 5)) + '☆'.repeat(Math.max(0, 5 - n));
    td.appendChild(stars);
  } else {
    td.textContent = ratingText || '';
  }
  return td;
}

// Toggle technical details in error panel
function toggleDetails() {
  const btn = document.getElementById('error-toggle');
  if (errorDetails.style.display === 'block') {
    errorDetails.style.display = 'none';
    btn.textContent = 'Show technical details';
  } else {
    errorDetails.style.display = 'block';
    btn.textContent = 'Hide technical details';
  }
}

// ─── CSV download ─────────────────────────────────────────────────────────────
function csvEscape(val) {
  if (val === null || val === undefined) return '""';
  return `"${val.toString().replace(/"/g, '""')}"`;
}

function downloadCSV() {
  if (!reviewsData || !reviewsData.length) return;

  const headers = ['Name', 'Rating', 'Date', 'Review', 'Response'];
  const rows = reviewsData.map(r => [
    csvEscape(r.name),
    csvEscape(r.rating),
    csvEscape(r.date),
    csvEscape(r.content),
    csvEscape(r.response)
  ].join(','));

  const bom = '\uFEFF';
  const csv = bom + [headers.join(','), ...rows].join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const date = new Date().toISOString().split('T')[0];

  const reader = new FileReader();
  reader.onload = function() {
    const dataUrl = reader.result;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const pageTitle = tabs?.[0]?.title || '';
      const placeName = pageTitle.split(' - ')[0].trim();
      const safeName  = placeName.replace(/[^a-z0-9]/gi, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
      const filename  = `gbp_reviews_${safeName || 'export'}_${date}.csv`;

      chrome.downloads.download({
        url: dataUrl,
        filename: filename,
        saveAs: false
      }, (downloadId) => {
        if (chrome.runtime.lastError) {
          // Fallback: try the anchor method
          const a = document.createElement('a');
          a.href = dataUrl;
          a.download = filename;
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
      });
    });
  };
  reader.readAsDataURL(blob);
}

// ─── Event listeners ──────────────────────────────────────────────────────────
document.getElementById('download-btn').addEventListener('click', downloadCSV);
document.getElementById('error-toggle').addEventListener('click', toggleDetails);
