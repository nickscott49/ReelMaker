# GBP Review Scraper — Chrome Extension

Extract Google Business Profile reviews from Google Search and Google Maps into a CSV file.

## Features

- One-click extraction from any Google Business listing
- Works on Google Search, Google Maps, and Knowledge Graph panels
- Real-time progress with step indicators
- Star rating display in preview table
- CSV export with UTF-8 BOM (Excel-friendly)
- Automatically sorts by Newest before scraping

## Installation

1. Download and unzip this folder
2. Open Chrome and go to `chrome://extensions`
3. Enable **Developer mode** (top-right toggle)
4. Click **Load unpacked** and select this folder
5. The extension icon will appear in your toolbar

## Usage

1. Navigate to a Google Business listing on Google Search or Google Maps
2. Click the extension icon in your Chrome toolbar
3. The side panel opens and scraping begins automatically
4. When complete, click **Download CSV** to save the file

## CSV Format

| Column | Description |
|--------|-------------|
| Name | Reviewer's display name |
| Rating | Star rating text (e.g. "5 stars") |
| Date | Review date (e.g. "2 weeks ago") |
| Review | Full review text |
| Response | Business owner's reply, if any |

## Troubleshooting

**Extension doesn't work / shows an error**
- Make sure you're on a page with a visible business listing
- Wait for the page to fully load, then try again
- Google occasionally changes their page structure — the selectors in `content.js` may need updating if this happens

**Only partial reviews scraped on Maps**
- Very large review sets (500+) may not fully load before the scroll limit is hit
- Try scrolling partway through the reviews manually before activating the extension

## Technical Details

- **Manifest Version**: 3
- **Permissions**: `activeTab`, `sidePanel`, `scripting`, `storage`, `webNavigation`
- **Browser**: Chrome 114+ (Side Panel API required)
- **Dependencies**: None — pure vanilla JS

## Notes

This extension is not affiliated with or endorsed by Google. Use in accordance with Google's Terms of Service. Provided as-is without warranty.
