// Content script for GBP Review Scraper

(function() {
  // Prevent double-injection
  if (window.__gbpScraperRunning) return;
  window.__gbpScraperRunning = true;

  // ─── Page type detection ───────────────────────────────────────────────────
  const href = window.location.href;
  const isSearchPage = /google\.[a-z.]+\/search/.test(href);
  const isMapsPage   = /google\.[a-z.]+\/maps/.test(href);

  if (!isSearchPage && !isMapsPage) {
    sendError(
      'Navigate to a Google Business listing first.',
      'This tool works on:\n• google.com/search (search results with a business panel)\n• google.com/maps (Maps business listing)'
    );
    return;
  }

  let pageType = 'search';
  let reviewsModalOpen = false;

  if (isSearchPage) {
    const rhsDiv = document.getElementById('rhs');
    const kpDiv  = document.querySelector('.kp-wholepage');
    if (rhsDiv && kpDiv) {
      pageType = 'search-kg';
      const reviewContainers = document.querySelectorAll('.bwb7ce');
      const newestButton = xpathOne("//*[@role='radio' or @role='button'][contains(., 'Newest')]");
      if (reviewContainers.length > 0 || newestButton) {
        reviewsModalOpen = true;
      }
    }
  } else if (isMapsPage) {
    pageType = 'maps';
  }

  // ─── Selectors ─────────────────────────────────────────────────────────────
  const CONFIGS = {
    search: {
      reviewsTab:      "//a[@role='tab' and .//span[normalize-space()='Reviews']]",
      newestSort:      "//span[normalize-space()='Newest']/ancestor::div[@role='radio']",
      scrollContainer: "#osuid_0",
      reviewContainer: "//div[contains(@class,'bwb7ce') and @jsname='ShBeI']",
      reviewerName:    ".//div[contains(@class,'Vpc5Fe')]",
      starRating:      ".//div[contains(@class,'dHX2k') and @role='img']/@aria-label",
      reviewDate:      ".//span[contains(@class,'y3Ibjb')]",
      reviewContent:   ".//div[contains(@class,'OA1nbd')]",
      reviewResponse:  ".//div[contains(@class,'KmCjbd')]",
      moreButtons:     "//div[contains(@class,'bwb7ce')]//a[normalize-space()='More'] | //div[contains(@class,'bwb7ce')]//*[starts-with(@aria-label, 'Read more') and substring(@aria-label, string-length(@aria-label) - 5) = 'review']"
    },
    'search-kg': {
      reviewsSpan:      "//div[contains(@ssk, '_local_action')]//span[normalize-space()='Reviews']",
      newestSpan:       "//*[@role='radio' or @role='button'][contains(., 'Newest')]",
      moreUserReviews:  "//*[@role='button'][contains(., 'More') and contains(., 'reviews')]",
      reviewContainer:  "//div[@jsname='GmP9w']//div[contains(@class,'bwb7ce')]",
      reviewerName:     ".//div[contains(@class,'Vpc5Fe')]",
      starRating:       ".//div[contains(@class,'dHX2k') and @role='img']/@aria-label",
      reviewDate:       ".//span[contains(@class,'y3Ibjb')]",
      reviewContent:    ".//div[contains(@class,'OA1nbd')]",
      reviewResponse:   ".//div[contains(@class,'KmCjbd')]",
      moreButtons:      "//div[contains(@class,'bwb7ce')]//a[normalize-space()='More' and @role='button'] | //div[contains(@class,'bwb7ce')]//*[starts-with(@aria-label, 'Read more') and substring(@aria-label, string-length(@aria-label) - 5) = 'review']"
    },
    maps: {
      reviewsTab:      "//button[@role='tab' and .//div[normalize-space()='Reviews']]",
      sortButton:      "//button[@aria-label='Sort reviews']",
      newestOption:    "//*[@role='menuitem' or @role='menuitemradio'][contains(., 'Newest')]",
      scrollContainer: "//div[@role='feed' and contains(@class, 'm6QErb')]",
      reviewContainer: "//div[contains(@class,'jftiEf')]",
      reviewerName:    ".//button[contains(@jsaction,'review.reviewerLink')]//div[contains(@class,'d4r55')]",
      starRating:      ".//span[@role='img' and contains(@aria-label,'star')]/@aria-label",
      reviewDate:      ".//span[contains(@class,'rsqaWe')]",
      reviewContent:   ".//span[contains(@class,'wiI7pd')]",
      reviewResponse:  ".//div[contains(@class,'CDe7pd')]//div[contains(@class,'wiI7pd')]",
      moreButtons:     "//button[contains(text(),'More') or contains(@aria-label,'More')]"
    }
  };

  const SEL = CONFIGS[pageType];

  const TIMING = {
    initialWait:        2000,
    scrollWait:         1800,
    clickWait:          300,
    moreButtonTimeout:  3000,
    moreUserReviewsWait: 2000
  };

  // ─── Messaging ─────────────────────────────────────────────────────────────
  function sendProgress(percent, text) {
    chrome.runtime.sendMessage({ type: 'progress', percent, text });
  }

  function sendError(message, details = '') {
    chrome.runtime.sendMessage({ type: 'error', message, details });
  }

  function sendReviews(reviews) {
    chrome.runtime.sendMessage({ type: 'reviews', data: reviews });
  }

  // ─── DOM helpers ───────────────────────────────────────────────────────────
  function xpathAll(xpath, context = document) {
    const result = document.evaluate(xpath, context, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const nodes = [];
    for (let i = 0; i < result.snapshotLength; i++) nodes.push(result.snapshotItem(i));
    return nodes;
  }

  function xpathOne(xpath, context = document) {
    return xpathAll(xpath, context)[0] || null;
  }

  function xpathAttr(xpath, context = document) {
    const result = document.evaluate(xpath, context, null, XPathResult.ANY_TYPE, null);
    const node = result.iterateNext();
    return node ? node.value : '';
  }

  async function waitForXPath(xpath, timeout = 6000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const el = xpathOne(xpath);
      if (el) return el;
      await sleep(120);
    }
    throw new Error(`Timed out waiting for element: ${xpath}`);
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function isVisible(el) {
    if (!el || el.offsetParent === null) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const s = window.getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }

  function simulateClick(el) {
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(type => {
      el.dispatchEvent(new (type.startsWith('pointer') ? PointerEvent : MouseEvent)(type, opts));
    });
  }

  // ─── Step 1: Open Reviews ──────────────────────────────────────────────────
  async function clickReviewsTab() {
    if (pageType === 'search-kg') {
      if (reviewsModalOpen) {
        sendProgress(15, 'Reviews already open, continuing…');
        await sleep(500);
        return;
      }

      sendProgress(10, 'Looking for Reviews button…');
      try {
        const el = await waitForXPath(SEL.reviewsSpan, 4000);
        sendProgress(12, 'Clicking Reviews (page may reload)…');
        chrome.runtime.sendMessage({ type: 'page_will_reload' });
        el.click();
        sendProgress(14, 'Waiting for page reload…');
        await new Promise(() => {}); // background will re-inject
      } catch (e) {
        sendError('Could not find the Reviews button.', e.message);
      }
      return;
    }

    sendProgress(10, 'Clicking the Reviews tab…');
    const tab = await waitForXPath(SEL.reviewsTab);
    tab.click();
    sendProgress(15, 'Reviews tab clicked, loading content…');
    await sleep(TIMING.initialWait);
  }

  // ─── Step 2: Sort by Newest ────────────────────────────────────────────────
  async function clickNewestSort() {
    if (pageType === 'search' || pageType === 'search-kg') {
      sendProgress(20, 'Setting sort to Newest…');
      const sortSelector = pageType === 'search' ? SEL.newestSort : SEL.newestSpan;
      const btn = await waitForXPath(sortSelector);
      btn.click();
      sendProgress(25, 'Sorted by newest.');
      await sleep(TIMING.initialWait);
      return;
    }

    // Google Maps — sort menu needs multi-strategy click
    sendProgress(20, 'Opening sort menu…');
    const sortBtn = await waitForXPath(SEL.sortButton);

    const strategies = [
      () => sortBtn.click(),
      () => simulateClick(sortBtn),
      () => { sortBtn.focus(); sortBtn.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true })); },
      () => { sortBtn.focus(); sortBtn.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', keyCode: 32, bubbles: true })); }
    ];

    let newestBtn = null;
    for (let i = 0; i < strategies.length; i++) {
      sendProgress(21, `Opening sort menu (attempt ${i + 1}/${strategies.length})…`);
      strategies[i]();
      await sleep(900);
      const options = xpathAll(SEL.newestOption);
      newestBtn = options.find(o => isVisible(o)) || null;
      if (newestBtn) break;
    }

    if (!newestBtn) throw new Error('Could not open the sort menu. Try scrolling to the reviews section first.');

    sendProgress(23, 'Selecting Newest…');
    newestBtn.click();
    simulateClick(newestBtn);
    await sleep(TIMING.initialWait);
    sendProgress(25, 'Sorted by newest.');
  }

  // ─── Step 3: Load all reviews ──────────────────────────────────────────────
  async function loadAllReviews() {
    if (pageType === 'search-kg') {
      sendProgress(30, 'Clicking "More reviews" to load all…');
      let clicks = 0;
      const MAX = 150;

      while (clicks < MAX) {
        const btns = xpathAll(SEL.moreUserReviews);
        if (!btns.length) { sendProgress(60, `All reviews loaded (${clicks} click${clicks !== 1 ? 's' : ''}).`); break; }

        try {
          btns[0].click();
          clicks++;
          sendProgress(Math.min(30 + clicks * 0.2, 57), `Loading more reviews… (${clicks})`);
          await sleep(TIMING.moreUserReviewsWait);
        } catch { break; }
      }
      if (clicks >= MAX) sendProgress(60, `Reached review load limit (${MAX} clicks).`);
      return;
    }

    sendProgress(30, 'Scrolling to load all reviews…');

    let container;
    if (pageType === 'search') {
      container = document.querySelector(SEL.scrollContainer);
    } else {
      // Maps: find scrollable ancestor of first review
      const reviews = xpathAll(SEL.reviewContainer);
      if (reviews.length) {
        let el = reviews[0].parentElement;
        while (el && el !== document.body) {
          const s = window.getComputedStyle(el);
          if ((s.overflowY === 'auto' || s.overflowY === 'scroll') && el.scrollHeight > el.clientHeight) {
            container = el;
            break;
          }
          el = el.parentElement;
        }
      }
      if (!container) {
        const nodes = xpathAll(SEL.scrollContainer);
        container = nodes[0] || null;
      }
    }

    if (!container) throw new Error('Could not find the reviews scroll container.');

    let prevHeight = 0, stable = 0, attempts = 0;
    const MAX_SCROLLS = 250;

    while (stable < 5 && attempts < MAX_SCROLLS) {
      container.scrollBy(0, 3000);
      attempts++;
      await sleep(TIMING.scrollWait);
      const h = container.scrollHeight;
      if (h === prevHeight) { stable++; } else { stable = 0; }
      prevHeight = h;
      sendProgress(Math.min(30 + attempts * 0.12, 57), `Scrolling… (${attempts} scrolls)`);
    }

    sendProgress(60, attempts >= MAX_SCROLLS
      ? `Hit scroll limit (${MAX_SCROLLS}). Some reviews may be missing.`
      : 'All reviews loaded.'
    );
  }

  // ─── Step 4: Expand truncated reviews ─────────────────────────────────────
  async function expandReviews() {
    sendProgress(65, 'Expanding truncated reviews…');
    let total = 0;

    // Keep clicking until no more "More" buttons appear
    for (let pass = 0; pass < 50; pass++) {
      const btns = xpathAll(SEL.moreButtons);
      if (!btns.length) break;

      let clicked = 0;
      for (const btn of btns) {
        if (isVisible(btn)) {
          try { btn.click(); total++; clicked++; await sleep(120); } catch { /* skip */ }
        }
      }

      sendProgress(Math.min(65 + total * 0.1, 78), `Expanded ${total} review${total !== 1 ? 's' : ''}…`);
      if (!clicked) break;
      await sleep(800);
    }

    sendProgress(80, total > 0 ? `Expanded ${total} truncated review${total !== 1 ? 's' : ''}.` : 'No truncated reviews.');
  }

  // ─── Step 5: Extract data ──────────────────────────────────────────────────
  function extractReviews() {
    sendProgress(85, 'Extracting review data…');
    const containers = xpathAll(SEL.reviewContainer);

    if (!containers.length) {
      throw new Error('No review elements found. Try scrolling to the reviews section manually, then run again.');
    }

    const reviews = [];
    let skipped = 0;

    containers.forEach((container, i) => {
      try {
        const nameNodes    = xpathAll(SEL.reviewerName, container);
        const dateNodes    = xpathAll(SEL.reviewDate, container);
        const contentNodes = xpathAll(SEL.reviewContent, container);
        const responseNodes = xpathAll(SEL.reviewResponse, container);
        const rating       = xpathAttr(SEL.starRating, container);

        const name    = nameNodes[0]?.textContent?.trim() || '';
        const date    = dateNodes[0]?.textContent?.trim() || '';
        const content = contentNodes[0]?.textContent?.trim() || '';
        const response = responseNodes[0]?.textContent?.trim() || '';

        // Skip incomplete entries (likely pagination artifacts)
        if (!name || !rating || !date) { skipped++; return; }

        reviews.push({ name, rating, date, content, response });

        if (i % 10 === 0) {
          sendProgress(
            Math.min(85 + (i / containers.length) * 12, 97),
            `Extracting… (${i + 1}/${containers.length})`
          );
        }
      } catch { skipped++; }
    });

    sendProgress(100, `Done! Extracted ${reviews.length} review${reviews.length !== 1 ? 's' : ''}${skipped ? ` (${skipped} incomplete skipped)` : ''}.`);
    return reviews;
  }

  // ─── Main ──────────────────────────────────────────────────────────────────
  async function run() {
    try {
      sendProgress(0, `Starting… (${pageType} page)`);
      await sleep(400);

      await clickReviewsTab();
      await clickNewestSort();
      await loadAllReviews();

      sendProgress(62, 'Waiting for lazy content to render…');
      await sleep(2000);

      await expandReviews();

      sendProgress(82, 'Final render wait…');
      await sleep(1500);

      const reviews = extractReviews();
      await sleep(300);
      sendReviews(reviews);
    } catch (err) {
      sendError(
        err.message || 'An unexpected error occurred.',
        err.stack || String(err)
      );
    } finally {
      window.__gbpScraperRunning = false;
    }
  }

  run();
})();
